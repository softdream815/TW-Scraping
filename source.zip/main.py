import tweepy, time, json, os, warnings, keyboard, shutil, datetime, glob
from threading import Timer
warnings.filterwarnings("ignore")


class RepeatTimer(Timer):
    def run(self):
        while not self.finished.wait(self.interval):
            self.function(*self.args,**self.kwargs)


def display():
    current = str(datetime.timedelta(seconds=(time.time() - main_time)))
    print(f"\r--> Records: {total} <-- --> Elapsed Time: {current[:-7]} <--", end="")


def exit_check():
    global stop
    if not stop:
        if keyboard.is_pressed("ctrl+alt+shift+q"):
            try:
                check_exit_th.cancel()
            except:
                pass
            stop = True


def create_map():
    global keys_map

    keys_map = {}
    for file in range(len(keys_files)):
        keys_map[file] = {}
        for key in range(1, 4):
            keys_map[file][key] = True
            

def get_auth(file, key):
    global twitter_api, active

    try:
        with open(file) as f:
            keys = json.load(f)

        twitter_api = tweepy.Client(bearer_token=keys[f"bearer_token_{key}"], consumer_key=keys[f"consumer_key_{key}"], consumer_secret=keys[f"consumer_secret_{key}"],
                                access_token=keys[f"access_token_key_{key}"], access_token_secret=keys[f"access_token_secret_{key}"])
        active = True
        return True
    except:
        return False
        

def get_user(user):
    global active, keys_map

    while True:
        found = False
        for file in range(len(keys_files)):
            for key in range(1, 4):
                try:
                    assert keys_map[file][key]
                    try:
                        assert active
                    except:
                        assert get_auth(keys_files[file], key)
                    try:
                        user_data = twitter_api.get_user(username=user)
                        found = True
                        break
                    except Exception as e:
                        active = False
                        if "429 Too Many Requests" in str(e):
                            keys_map[file][key] = False
                        else:
                            return None
                except:
                    continue
            if found:
                break
        if found:
            break
        else:
            create_map()

    return user_data.data["id"]


def get_user_followers(input_id):
    global followers_list, total

    pagination = None
    while True:
        found = False
        if stop:
            break
        
        for file in range(len(keys_files)):
            for key in range(1, 4):
                try:
                    assert keys_map[file][key]
                    try:
                        assert active
                    except:
                        assert get_auth(keys_files[file], key)
                    try:
                        followers = twitter_api.get_users_followers(id=str(input_id), max_results=1000, pagination_token=pagination)
                        found = True
                        break
                    except Exception as e:
                        active = False
                        if "429 Too Many Requests" in str(e):
                            keys_map[file][key] = False
                        else:
                            continue
                except:
                    continue

            if found:
                break
        if not found:
            create_map()
            continue

        try:
            for follower in followers.data:
                if stop:
                    break

                followers_list.append(follower.data["username"])
                total += 1
        except:
            pass
        
        try:
            pagination = followers.meta["next_token"]
        except:
            break


def main():
    global followers_list, check_exit_th, stop, keys_files, total, active
    active = False
    total = 0
    stop = False
    followers_list = []

    if not os.path.isdir("Results"):
        os.mkdir("Results")

    try:
        with open("list.txt", encoding="utf-8") as file:
            inputs = file.read().split("\n")
    except:
        print("\nMissing input files\n")
        return

    keys_files = glob.glob("keys/*.json")
    create_map()

    check_exit_th = RepeatTimer(0.01, exit_check)
    check_exit_th.start()

    timer_th = RepeatTimer(1, display)
    timer_th.start()

    for user in inputs:
        input_id = get_user(user.strip())
        try:
            assert input_id
            get_user_followers(input_id)
        except:
            continue

        try:
            with open(f"Results/{user}.txt", "wb") as file:
                file.write(("\n".join(followers_list)).encode())
        except:
            try:
                with open(f"Results/{time.strftime('%m-%d-%Y (%H%M%S)')}.txt", "wb") as file:
                    file.write(("\n".join(followers_list)).encode())
            except:
                pass

    try:
        time.sleep(2)
        timer_th.cancel()
    except:
        pass
    try:
        check_exit_th.cancel()
    except:
        pass


if __name__ == "__main__":
    print("--> Starting <--")
    print("\n--> Press \"ctrl+alt+shift+q\" to stop <--\n")
    print("-"*30, end="\n\n")
    main_time = time.time()
    main()
    print("\n\n", "-"*30, sep="")
    print(f"\n--> Finished in {str(datetime.timedelta(seconds=(time.time() - main_time)))[:-7]} <--\n")
    print("-"*30)
    input("\n--> Press Enter to exit <--\n")
    try:
        shutil.rmtree("temp")
    except:
        pass
    print("Exiting in:")
    for i in range(5, 0, -1):
        print(i)
        time.sleep(1)